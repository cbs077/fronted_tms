<template>
  <table-common-button>
    <template #body>
      <div class="grow"></div>
      <base-button text="엑셀저장" class="mr-1" />
    </template>
  </table-common-button>

  <table class="mb-6 w-full border-collapse border border-sk-gray">
    <tr>
      <td class="h-10 w-3/12 border border-sk-gray bg-sk-lightgray text-center">
        VAN사명
      </td>
      <td colspan="4" class="text-center">SKSKSK</td>
    </tr>
  </table>
  <div class="rounded border border-sk-gray">
    <el-table :data="devices" fit class="rounded" @row-click="onRowClicked">
      <el-table-column prop="van" label="VAN사명" align="center" />
      <el-table-column prop="modelName" label="단말기 모델" align="center" />

      <el-table-column prop="deviceCount" label="단말기 수량" align="center" />
      <el-table-column prop="swDownload" label="초기상태" align="center" />
      <el-table-column prop="swDownload" label="사용중" align="center" />
      <el-table-column prop="swDownload" label="휴면상태" align="center" />
    </el-table>
  </div>

  <div class="flex justify-center">
    <el-pagination
      background
      class="my-6"
      layout="prev, pager, next"
      :total="1000"
    ></el-pagination>
  </div>

  <device-usage-detail-modal
    v-model="deviceUsageDetail.modal"
  ></device-usage-detail-modal>
</template>

<script lang="ts">
import { defineComponent, reactive, ref } from "vue";

import BaseButton from "~/components/atoms/base-button.vue";
import OptionsSearchButton from "~/components/molecules/options-search-button.vue";
import TableCommonButton from "~/components/molecules/table/table-common-button.vue";
import DeviceUsageDetailModal from "~/components/templates/modals/device-usage-detail.modal.vue";
import { useConst } from "~/hooks/const.hooks";
import { IDevice, useDevice } from "~/hooks/devices.hooks";

export default defineComponent({
  name: "DeviceRegistrationLogs",
  components: {
    TableCommonButton,
    DeviceUsageDetailModal,
    BaseButton,
    OptionsSearchButton,
  },
  setup() {
    const { logHeaders: headers, devices } = useDevice();
    const { deviceModels, searchOptions } = useConst();
    const selectOption = ref();
    const displayOptions = reactive({
      all: false,
      modelCode: false,
      van: false,
    });

    const selectDataRange = reactive({
      start: new Date(),
      end: new Date(),
    });

    const deviceUsageDetail = reactive({
      modal: false,
    });

    const onRowClicked = (row: IDevice) => {
      deviceUsageDetail.modal = true;
    };

    return {
      displayOptions,
      searchOptions,
      selectOption,
      deviceUsageDetail,
      onRowClicked,
      headers,
      selectDataRange,
      devices,
      deviceModels,
    };
  },
});
</script>
