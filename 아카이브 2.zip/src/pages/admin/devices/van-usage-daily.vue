<template>
  <div class="mb-4 rounded border border-sk-gray bg-option-background p-3 pl-8">
    <div class="my-3 flex flex-row">
      <div class="my-auto w-1/12">조회일</div>

      <div class="flex w-10/12">
        <div class="block">
          <el-date-picker
            v-model="selectDataRange.start"
            size="large"
          ></el-date-picker>
        </div>
        <p class="mx-2 translate-y-1 transition">~</p>
        <div class="block">
          <el-date-picker
            v-model="selectDataRange.end"
            size="large"
          ></el-date-picker>
        </div>
      </div>
    </div>

    <div class="my-3 flex flex-row">
      <div class="my-auto w-1/12">검색조건</div>

      <div class="my-auto w-5/12 pr-5">
        <el-select
          v-model="selectOption"
          clearable
          placeholder="선택"
          size="large"
          class="w-full"
        >
          <el-option
            v-for="item in searchOptions"
            :key="item.value"
            :label="item.value"
            :value="item.value"
          >
          </el-option>
        </el-select>
      </div>

      <div class="my-auto w-1/12 text-center">검색어</div>
      <div class="w-80 w-5/12">
        <el-input size="large" />
      </div>
    </div>

    <div class="my-3 flex">
      <div class="my-auto block w-1/12 align-middle">결과 데이터</div>
      <el-checkbox
        v-model="displayOptions.all"
        label="전체"
        size="large"
      ></el-checkbox>
      <el-checkbox
        v-model="displayOptions.modelCode"
        label="단말기 모델 코드"
        size="large"
      ></el-checkbox>
      <el-checkbox
        v-model="displayOptions.van"
        label="VAN사명"
        size="large"
      ></el-checkbox>
    </div>

    <options-search-button />
  </div>

  <table-common-button>
    <template #body>
      <div class="grow"></div>
      <base-button text="엑셀저장" class="mr-1" />
    </template>
  </table-common-button>
  <div class="rounded border border-sk-gray">
    <el-table :data="devices" fit class="rounded" @row-click="onRowClicked">
      <el-table-column prop="van" label="VAN사명" align="center" />
      <el-table-column prop="modelName" label="단말기 모델" align="center" />

      <el-table-column prop="deviceCount" label="단말기 수량" align="center" />
      <el-table-column
        prop="swDownload"
        label="S/W Download 건수"
        align="center"
      />
    </el-table>
  </div>

  <div class="flex justify-center">
    <el-pagination
      background
      class="my-6"
      layout="prev, pager, next"
      :total="1000"
    ></el-pagination>
  </div>

  <device-usage-detail-modal
    v-model="deviceUsageDetail.modal"
  ></device-usage-detail-modal>
</template>

<script lang="ts">
import { defineComponent, reactive, ref } from "vue";

import BaseButton from "~/components/atoms/base-button.vue";
import OptionsSearchButton from "~/components/molecules/options-search-button.vue";
import TableCommonButton from "~/components/molecules/table/table-common-button.vue";
import DeviceUsageDetailModal from "~/components/templates/modals/device-usage-detail.modal.vue";
import { useConst } from "~/hooks/const.hooks";
import { IDevice, useDevice } from "~/hooks/devices.hooks";

export default defineComponent({
  name: "DeviceRegistrationLogs",
  components: {
    TableCommonButton,
    DeviceUsageDetailModal,
    BaseButton,
    OptionsSearchButton,
  },
  setup() {
    const { logHeaders: headers, devices } = useDevice();
    const { deviceModels, searchOptions } = useConst();
    const selectOption = ref();
    const displayOptions = reactive({
      all: false,
      modelCode: false,
      van: false,
    });

    const selectDataRange = reactive({
      start: new Date(),
      end: new Date(),
    });

    const deviceUsageDetail = reactive({
      modal: false,
    });

    const onRowClicked = (row: IDevice) => {
      deviceUsageDetail.modal = true;
    };

    return {
      displayOptions,
      searchOptions,
      selectOption,
      deviceUsageDetail,
      onRowClicked,
      headers,
      selectDataRange,
      devices,
      deviceModels,
    };
  },
});
</script>
