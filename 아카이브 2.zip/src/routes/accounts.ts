import { RouteRecordRaw } from "vue-router";

const accountRoutes: RouteRecordRaw[] = [
  {
    path: "/van/accounts/users",
    component: () => import("../pages/accounts/user.vue"),
  },
];

export default accountRoutes;
