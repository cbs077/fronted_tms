import "./assets/main.css";
import "./assets/theme.scss";

import ElementPlus from "element-plus";
// @ts-ignore
import drag from "v-drag";
import { createApp } from "vue";

import App from "./App.vue";
import router from "./routes";

createApp(App).use(router).use(drag).use(ElementPlus).mount("#app");
