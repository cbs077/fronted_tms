export interface IDataTableHeader {
  key: string;
  value?: string;
  align?: "left" | "right" | "center";
}
