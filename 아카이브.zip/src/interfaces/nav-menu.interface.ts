export interface INavMenuItem {
  text: string;
  to: string;
  href?: string;
  active?: boolean;
}
