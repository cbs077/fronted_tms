export type DEVICE_REGISTER_TYPE = "일반등록" | "일괄등록";
